package com.example.academiaCTD.entity;


public class Clientes {

    private Integer id;
    private String nome;
    private String sobrenome;
    private int matricula;
    private double altura;
    private double peso;
    private String email;
    private String senha;

    public Clientes(String nome, String sobrenome, int matricula, double altura, double peso, String email, String senha) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.matricula = matricula;
        this.altura = altura;
        this.peso = peso;
        this.email = email;
        this.senha = senha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}

