package com.example.academiaCTD.entity.DTO;

public @interface NotEmpty {
    String message();
}
