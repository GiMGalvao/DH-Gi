package com.dh.hoteis.dao;

public interface IFilialDao<T> {
    T save(T t);
}
