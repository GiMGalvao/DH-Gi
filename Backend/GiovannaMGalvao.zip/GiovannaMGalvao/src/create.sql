create table if not exists hoteis (id int auto_increment primary key, nomeDaFilial varchar(255),
rua varchar(255),numero int(255), cidade varchar(255), estado varchar(255), ehCincoEstrelas BOOLEAN);

