public class SerieNaoHabilitadoException extends Exception {

    public SerieNaoHabilitadoException (String naoHabilitado) {super (naoHabilitado);

    }

}
