package com.example.trainerProf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainerProfApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainerProfApplication.class, args);
	}

}
