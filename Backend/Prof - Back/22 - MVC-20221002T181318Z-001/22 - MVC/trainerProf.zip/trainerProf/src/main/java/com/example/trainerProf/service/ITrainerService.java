package com.example.trainerProf.service;

import com.example.trainerProf.model.Trainer;

import java.util.List;

public interface ITrainerService {
    List<Trainer>  listTrainer();
}
