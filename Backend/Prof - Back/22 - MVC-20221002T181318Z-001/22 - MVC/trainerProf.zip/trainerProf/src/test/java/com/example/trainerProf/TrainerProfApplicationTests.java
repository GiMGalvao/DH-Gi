package com.example.trainerProf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerProfApplicationTests {

	@Test
	void contextLoads() {
	}

}
