package com.example.clinicaProf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaProfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaProfApplication.class, args);
	}

}
