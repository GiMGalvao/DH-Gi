package com.example.BackendClientProf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendClientProfApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendClientProfApplication.class, args);
	}

}
