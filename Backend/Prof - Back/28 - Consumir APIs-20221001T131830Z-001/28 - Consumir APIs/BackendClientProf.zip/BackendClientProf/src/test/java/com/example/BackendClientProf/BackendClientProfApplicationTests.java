package com.example.BackendClientProf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendClientProfApplicationTests {

	@Test
	void contextLoads() {
	}

}
