package com.example.CTDCommerceProf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtdCommerceProfApplicationTests {

	@Test
	void contextLoads() {
	}

}
