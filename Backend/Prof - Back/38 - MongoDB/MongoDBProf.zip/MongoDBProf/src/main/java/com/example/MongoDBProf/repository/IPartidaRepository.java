package com.example.MongoDBProf.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface IPartidaRepository {
}
