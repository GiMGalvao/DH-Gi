package com.example.MongoDBProf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbProfApplicationTests {

	@Test
	void contextLoads() {
	}

}
