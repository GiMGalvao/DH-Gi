package com.example.MongoDBProf.model;

public enum Status {
    AGENDADA,
    PARA_COMECAR,
    AO_VIVO,
    ENCERRADA;
}
