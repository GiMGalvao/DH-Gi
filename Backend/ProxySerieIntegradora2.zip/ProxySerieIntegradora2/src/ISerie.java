public interface ISerie {
    public String getSerie (String nome);
}
