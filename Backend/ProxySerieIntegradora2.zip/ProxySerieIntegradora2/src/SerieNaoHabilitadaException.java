public class SerieNaoHabilitadaException extends Exception{
    public SerieNaoHabilitadaException(String msg) {
        super(msg);
    }
}
