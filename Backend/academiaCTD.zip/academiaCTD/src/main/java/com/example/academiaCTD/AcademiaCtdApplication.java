package com.example.academiaCTD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiaCtdApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademiaCtdApplication.class, args);
	}

}
