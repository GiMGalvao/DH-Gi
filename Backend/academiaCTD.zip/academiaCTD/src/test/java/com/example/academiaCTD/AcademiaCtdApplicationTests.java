package com.example.academiaCTD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademiaCtdApplicationTests {

	@Test
	void contextLoads() {
	}

}
