
package adotarDogs;

public class Main {
    public static void main(String[] args) {

        CachorrosParaAdocao cao1 = new CachorrosParaAdocao("Mel", "Labrador", 10, false, 2002, true);
        cao1.resultado();
       CachorrosParaAdocao cao2 = new CachorrosParaAdocao("Milly", "Poodle", 3, true, 2010, false);
       cao2.resultado();
    }
}


