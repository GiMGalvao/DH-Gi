package hoteis.dao.impl;

import hoteis.dao.ConfiguracaoJDBC;
import hoteis.dao.IDao;
import hoteis.model.Filial;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FilialDaoImpl implements IDao<Filial> {
    private ConfiguracaoJDBC configuracaoJDBC;
    final static Logger log = Logger.getLogger(FilialDaoImpl.class);

    public FilialDaoImpl(ConfiguracaoJDBC configuracaoJDBC) {
        this.configuracaoJDBC = configuracaoJDBC;
    }

    @Override
    public Filial salvar(Filial filial) {
        log.debug("Salvando a filial...");
        Connection connection = configuracaoJDBC.conectarBD();
        Statement statement = null;
        String query = String.format("INSERT INTO filial(nome,rua,numero,cidade,estado,e5estrelas) VALUES('%s','%s','%s','%s','%s','%s');",
                filial.getNome(),filial.getRua(),filial.getNumero(),filial.getCidade(),filial.getEstado(),filial.isE5estrelas());
        try{
            statement = connection.createStatement();
            statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
            ResultSet resultSet = statement.getGeneratedKeys();
            if (resultSet.next()){
                log.debug("Amazernando o id da memoria");
                filial.setId(resultSet.getInt(1));
            }

            log.debug("Fechando a conexão");
            connection.close();

        } catch (Exception e) {
            log.error(e.getMessage());
            e.printStackTrace();
        }
        log.debug("Retornado a filial");
        return filial;
    }

    @Override
    public List<Filial> buscarTudo() {
        List<Filial> lista = new ArrayList<>();
        log.debug("buscando a lista de filial...");
        Connection connection = configuracaoJDBC.conectarBD();
        Statement statement = null;
        String query = "SELECT * FROM filial;";
        try{
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()){
                Filial filial = new Filial();
                log.debug("Amazernando a filial da memoria");
                filial.setId(resultSet.getInt(1));
                filial.setNome(resultSet.getString(2));
                filial.setRua(resultSet.getString(3));
                filial.setNumero(resultSet.getString(4));
                filial.setCidade(resultSet.getString(5));
                filial.setEstado(resultSet.getString(6));
                filial.setE5estrelas(resultSet.getBoolean(7));
                lista.add(filial);
            }
            log.debug("Fechando a conexão");
            connection.close();

        } catch (Exception e) {
            log.error(e.getMessage());
            e.printStackTrace();
        }
        log.debug("Retornado a lista de filial");
        return lista;
    }
}
