package hoteis.service;

import hoteis.dao.IDao;
import hoteis.dao.impl.FilialDaoImpl;
import hoteis.model.Filial;

import java.util.List;

public class FilialService {
    IDao<Filial> filialIDao;

    public FilialService(IDao<Filial> filialIDao) {
        this.filialIDao = filialIDao;
    }

    public Filial salvar(Filial filial) {
        return this.filialIDao.salvar(filial);
    }

    public List<Filial> buscarTudo() {
        return this.filialIDao.buscarTudo();
    }
}
