package test;
import hoteis.dao.ConfiguracaoJDBC;
import hoteis.dao.impl.FilialDaoImpl;
import hoteis.model.Filial;
import hoteis.service.FilialService;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FilialServiceTest {
    private FilialService filialService = new FilialService(new FilialDaoImpl(new ConfiguracaoJDBC()));

    @Test
    public void salvarFilial() {
        Filial filial1 = new Filial("Hotel Tijuquinha", "Rua Diego da Souza", "89B", "Palmas", "Tocatins", false);
        filialService.salvar(filial1);
        assertTrue(filial1.getId() != null);
        Filial filial2 = new Filial("Hotel da Ostra", "Rua José da Souza", "89B", "Tijucas", "Santa Catarina", false);
        filialService.salvar(filial2);
        assertTrue(filial2.getId() != null);
        Filial filial3 = new Filial("Hotel do Pão de queijo", "Rua Diego da Silva", "8B", "Belo Horizonte", "Minas Gerais", true);
        filialService.salvar(filial3);
        assertTrue(filial3.getId() != null);
        Filial filial4 = new Filial("Hotel Capirinha", "Rua antonio da capivara", "84A", "Rio de janeiro", "Rio de janeiro", false);
        filialService.salvar(filial4);
        assertTrue(filial4.getId() != null);
        Filial filial5 = new Filial("Hotel Capivara", "Rua Diego da Oliveira", "98B", "Brasilia", "Distrito Federal", true);
        filialService.salvar(filial5);
        assertTrue(filial5.getId() != null);

        List lista = filialService.buscarTudo();

        for(Object item : lista){
            System.out.println(item.toString());
        }
    }
}