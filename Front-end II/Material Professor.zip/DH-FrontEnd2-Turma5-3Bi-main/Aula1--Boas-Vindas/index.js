//Declarando uma variável do tipo Textual(String)
var nome = "Marcos Martins";

//Exibindo a informação no console
console.log("Olá, meu nome é " + nome);

//Declarando array e passando objetos textuais 
let nomes = ["Marcos", "Carlos", "Tatiane", "João"];

//Percorrendo o array e iterando sobre os dados
for (let i = 0; i < nomes.length; i++) {

    //Atribui a uma variável o nome da iteração
    let nomeCapturado = nomes[i];

    //Exibindo as informações capturadas
    console.log(nomeCapturado);
}






