let multiplicar = (valor1, valor2) => parseFloat(valor1) * parseFloat(valor2);

/* function multiplicar(valor1, valor2) {
  let valor1C = parseFloat(valor1);
  let valor2C = parseFloat(valor2);

  return valor1C * valor2C;
} */
