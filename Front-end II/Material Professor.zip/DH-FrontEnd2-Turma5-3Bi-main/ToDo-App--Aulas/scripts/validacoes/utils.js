function retiraEspacosDeUmValorInformado (recebeValor) {
    return recebeValor.trim();
}

function converteValorRecebidoEmMinusculo(recebeValor) {
    return recebeValor.toLowerCase();
}