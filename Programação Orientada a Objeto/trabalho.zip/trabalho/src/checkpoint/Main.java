package checkpoint;

public class Main {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Produto produto = new Produto();


}
